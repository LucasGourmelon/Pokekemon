import { Pokemon } from '../data/class_pokemon.js';
Pokemon.import_pokemon();

document.getElementById("getAttacksByType").addEventListener("click", () => {
    const typeName = document.getElementById("typeInput").value;
    return Object.values(Pokemon.all_pokemons).filter((p) => {
        return p.types.includes(typeName);
    })  
});

document.getElementById("getPokemonByAttack").addEventListener("click", () => {
    // Filtrer les pokemons par attaque
    return Object.values(Pokemon.all_pokemons).filter((p) => {
        return p.types.includes(attackName);
    })
});

const getAttacksByName = (typeName) => {
    return Object.values(Attack.all_attacks).filter((p) => {
        return p.types == typeName;
    })
}

const sortPokemonByName = () => {
    return Object.values(Pokemon.all_pokemons).sort(pokemonName)
};

const sortPokemonByStamina = () => {
    return Object.values(Pokemon.all_pokemons).sort(a.stamina - b.stamina);
}

const getWeakestEnemies = (attackName) => {
    let attack = Attack.all_attacks[attackName];
    let typesefficacite = {};

    // Récupérer l'efficacité de l'attaque par rapport au type
    attack.getType().forEach(type => {
        typesefficacite[type] = attack.getEffectivenessByType(type);
    });

    let efficacitePokemons = Object.values(Pokemon.all_pokemons).map(pokemon => {
        let efficacite = pokemon.getTypes().reduce((total, type) => {
            return total * Type.getEffectivenessByType(type);
        }, 1); // Commencer avec une efficacité initiale de 1
    
        return { pokemon: pokemon, efficacite: efficacite };  // Regroupe les pokemons et l'efficacité
    });
    

    let efficaciteMax = Math.max(...efficacitePokemons.map(p => p.efficacite));

    let pokemonsNuls = efficacitePokemons.filter(p => p.efficacite === efficaciteMax).map(p => p.pokemon); // Filtre sur le maximum de l'efficacité

    return pokemonsNuls;
};


const getBestAttacksForEnemy = (name) => {
    // Récupérer le Pokémon associé au nom ainsi que ses types
    let pokemon = Object.values(Pokemon.all_pokemons).find((p) => p.name === name);
    let types = pokemon.getTypes();

    // Récupérer l'efficacité de chaque type de Pokémon par rapport à ce Pokémon
    let typesEfficacite = Object.values(Type.all_types).map((type) => {
        let efficacite = types
            .map((t) => type.getEffectivenessByType(t.name))
            .reduce((total, type) => total * type, 1); // Commencer avec une efficacité initiale de 1
        return { type, efficacite };
    });

    // Trouver le type ou les types les plus efficaces pour le Pokémon donné
    let meilleursTypes = typesEfficacite.reduce((total, { type, efficacite }) => {
        // Si cette efficacité est supérieure à l'ancienne, recréer l'objet de stockage
        if (efficacite > total.efficacite) {
            return { types: [type], efficacite };
        // Sinon, si c'est égal, ajouter ce type à l'objet de stockage
        } else if (efficacite === total.efficacite) {
            total.types.push(type);
        }
        // Retourner l'objet de stockage
        return total;
    }, { types: [], efficacite: -1 }); // Valeur à -1 car il y'aura forcément des pokemons avec des efficacités supérieures

    return meilleursTypes.types;
}

const getArgs = () => {
    const input = document.getElementById("args");
    return input.value;
}

const a = document.querySelectorAll('a');
a.forEach((e) => {
    e.addEventListener('click', (s) => {
        s.preventDefault();
    })
})